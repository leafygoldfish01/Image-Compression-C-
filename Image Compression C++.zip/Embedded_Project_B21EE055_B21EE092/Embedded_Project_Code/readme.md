1. unzip the project
2. you must have installation of opencv cv2 to run this project
    follow this link to install opne cv2 -- "https://docs.opencv.org/4.x/d3/d52/tutorial_windows_install.html"
3. to run firstly build the project using command : "make"
4. get the current directory of project
5. then run the file DisplayImage using command : "./DisplayImage"
6. then enter the address of image on your pc like one image in this folder has address which you can use as sample, command : "./image.png"
7. then fill the other details as number of colors, command : "70"
8. then number of train steps as command : "40"

